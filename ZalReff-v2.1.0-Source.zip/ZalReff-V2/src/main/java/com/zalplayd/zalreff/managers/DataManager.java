package com.zalplayd.zalreff.managers;

import com.zalplayd.zalreff.ZalReff;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DataManager {
    public static class Referral {
        public final UUID uuid; public String name, code; public long playtimeSeconds, claimedAt; public boolean valid;
        Referral(UUID uuid, String name, String code, long playtimeSeconds, long claimedAt, boolean valid) {
            this.uuid=uuid; this.name=name; this.code=code; this.playtimeSeconds=playtimeSeconds; this.claimedAt=claimedAt; this.valid=valid;
        }
    }
    private final ZalReff plugin; private final File file;
    private final Map<UUID, Referral> referrals = new ConcurrentHashMap<>();
    private final Map<String, Integer> weeklyCounts = new ConcurrentHashMap<>();
    private String weekKey;
    private volatile long requiredSeconds;
    public DataManager(ZalReff plugin) { this.plugin=plugin; this.file=new File(plugin.getDataFolder(), "data.yml"); reloadSettings(); load(); }
    public void reloadSettings() { requiredSeconds=Math.max(1, plugin.getConfig().getLong("settings.required-playtime-minutes",60))*60L; }
    private String currentWeek() { LocalDate d=LocalDate.now(); WeekFields wf=WeekFields.ISO; return d.get(wf.weekBasedYear())+"-W"+String.format("%02d",d.get(wf.weekOfWeekBasedYear())); }
    private void rotateWeek() { String now=currentWeek(); if (!now.equals(weekKey)) { weeklyCounts.clear(); weekKey=now; } }
    public synchronized void load() {
        if (!file.exists()) return; YamlConfiguration y=YamlConfiguration.loadConfiguration(file); weekKey=y.getString("week",currentWeek());
        ConfigurationSection players=y.getConfigurationSection("players"); if(players!=null) for(String id:players.getKeys(false)) try {
            UUID uuid=UUID.fromString(id); String p="players."+id+".";
            referrals.put(uuid,new Referral(uuid,y.getString(p+"name","Unknown"),y.getString(p+"code",""),y.getLong(p+"playtime-seconds"),y.getLong(p+"claimed-at"),y.getBoolean(p+"valid")));
        } catch(IllegalArgumentException ignored) { }
        ConfigurationSection counts=y.getConfigurationSection("weekly-counts"); if(counts!=null) for(String code:counts.getKeys(false)) weeklyCounts.put(code,counts.getInt(code)); rotateWeek();
    }
    public synchronized void save() {
        rotateWeek(); YamlConfiguration y=new YamlConfiguration(); y.set("week",weekKey);
        for(Referral r:referrals.values()) { String p="players."+r.uuid+"."; y.set(p+"name",r.name); y.set(p+"code",r.code); y.set(p+"playtime-seconds",r.playtimeSeconds); y.set(p+"claimed-at",r.claimedAt); y.set(p+"valid",r.valid); }
        weeklyCounts.forEach((k,v)->y.set("weekly-counts."+k,v));
        try { if(!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs(); y.save(file); } catch(IOException e) { plugin.getLogger().severe("Gagal menyimpan data.yml: "+e.getMessage()); }
    }
    public Referral get(UUID uuid) { return referrals.get(uuid); }
    public Referral getByName(String name) { for(Referral r:referrals.values()) if(r.name.equalsIgnoreCase(name)) return r; return null; }
    public boolean claim(UUID uuid,String name,String code) { if(referrals.containsKey(uuid)) return false; referrals.put(uuid,new Referral(uuid,name,code,0,System.currentTimeMillis(),false)); return true; }
    public boolean addActiveSecond(UUID uuid,String name) {
        Referral r=referrals.get(uuid); if(r==null || r.valid) return false; r.name=name; r.playtimeSeconds++;
        if(r.playtimeSeconds>=requiredSeconds) { r.valid=true; rotateWeek(); weeklyCounts.merge(r.code,1,Integer::sum); return true; } return false;
    }
    public long requiredSeconds() { return requiredSeconds; }
    public Map<String,Integer> getWeeklyTop() { rotateWeek(); Map<String,Integer> copy=new HashMap<>(weeklyCounts); return copy; }
    public Collection<String> getCodes() { ConfigurationSection section=plugin.getConfig().getConfigurationSection("referral-codes"); return section == null ? Collections.emptyList() : new ArrayList<>(section.getKeys(false)); }
}

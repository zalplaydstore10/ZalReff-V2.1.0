package com.zalplayd.zalreff.listeners;

import com.zalplayd.zalreff.ZalReff;
import com.zalplayd.zalreff.managers.DataManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PlaytimeListener implements Listener {
    private final ZalReff plugin; private final Map<UUID,Long> lastActivity=new ConcurrentHashMap<>(); private final Map<UUID,Boolean> afk=new ConcurrentHashMap<>();
    public PlaytimeListener(ZalReff plugin) { this.plugin=plugin; Bukkit.getScheduler().runTaskTimer(plugin,this::tick,20L,20L); }
    private void activity(Player p) { UUID id=p.getUniqueId(); long now=System.currentTimeMillis(); boolean wasAfk=afk.getOrDefault(id,false); lastActivity.put(id,now); if(wasAfk) { afk.put(id,false); plugin.messages().send(p,"afk-resumed"); } }
    @EventHandler public void onJoin(PlayerJoinEvent e) { lastActivity.put(e.getPlayer().getUniqueId(),System.currentTimeMillis()); afk.put(e.getPlayer().getUniqueId(),false); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { lastActivity.remove(e.getPlayer().getUniqueId()); afk.remove(e.getPlayer().getUniqueId()); }
    @EventHandler public void onMove(PlayerMoveEvent e) { Location f=e.getFrom(),t=e.getTo(); if(t!=null && (f.getBlockX()!=t.getBlockX() || f.getBlockY()!=t.getBlockY() || f.getBlockZ()!=t.getBlockZ())) activity(e.getPlayer()); }
    @EventHandler public void onBreak(BlockBreakEvent e) { activity(e.getPlayer()); }
    @EventHandler public void onChat(AsyncPlayerChatEvent e) { UUID id=e.getPlayer().getUniqueId(); long now=System.currentTimeMillis(); boolean wasAfk=afk.getOrDefault(id,false); lastActivity.put(id,now); if(wasAfk) Bukkit.getScheduler().runTask(plugin,()->{afk.put(id,false);plugin.messages().send(e.getPlayer(),"afk-resumed");}); }
    private void tick() {
        long timeout=Math.max(1,plugin.getConfig().getLong("settings.afk-timeout-seconds",120))*1000L; long now=System.currentTimeMillis();
        for(Player p:Bukkit.getOnlinePlayers()) { UUID id=p.getUniqueId(); long last=lastActivity.getOrDefault(id,now); boolean idle=now-last>timeout;
            if(idle && !afk.getOrDefault(id,false)) { afk.put(id,true); plugin.messages().send(p,"afk-warning"); }
            if(!idle && !afk.getOrDefault(id,false) && plugin.data().addActiveSecond(id,p.getName())) {
                DataManager.Referral r=plugin.data().get(id); Bukkit.broadcastMessage(plugin.messages().get("reff-valid-broadcast",Map.of("player",p.getName(),"kode",r.code))); plugin.messages().send(p,"reff-valid-player",Map.of("kode",r.code));
                plugin.economy().pay(p, plugin.economy().reward("player-on-valid"), "referral valid");
                String streamer = plugin.getConfig().getString("referral-codes." + r.code + ".streamer", "");
                plugin.economy().payStreamer(streamer, plugin.economy().streamerReward(r.code, "valid", "streamer-on-valid"), "referral valid");
            }
        }
    }
}

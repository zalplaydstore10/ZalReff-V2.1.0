package com.zalplayd.zalreff.managers;

import com.zalplayd.zalreff.ZalReff;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class EconomyManager {
    private final ZalReff plugin; private Economy economy;
    public EconomyManager(ZalReff plugin) { this.plugin=plugin; setup(); }
    public void setup() { economy=null; if (!plugin.getConfig().getBoolean("economy.enabled", true)) return; if (Bukkit.getPluginManager().getPlugin("Vault")==null) return; RegisteredServiceProvider<Economy> rsp=Bukkit.getServicesManager().getRegistration(Economy.class); if(rsp!=null) economy=rsp.getProvider(); }
    public boolean available() { return economy!=null; }
    public boolean pay(Player player, double amount, String reason) { if(economy==null || amount<=0) return false; economy.depositPlayer(player, amount); plugin.getLogger().info("Reward "+amount+" diberikan kepada "+player.getName()+" ("+reason+")"); return true; }
    public boolean payStreamer(String name,double amount,String reason) { if(economy==null || name==null || name.isBlank() || amount<=0) return false; OfflinePlayer target=Bukkit.getOfflinePlayer(name); economy.depositPlayer(target,amount); plugin.getLogger().info("Reward streamer "+amount+" diberikan kepada "+name+" ("+reason+")"); return true; }
    public double reward(String path) { return Math.max(0,plugin.getConfig().getDouble("economy.rewards."+path,0)); }
    /** Per-referral-code streamer bonus; falls back to the global reward when unset. */
    public double streamerReward(String code, String stage, String fallbackPath) {
        String path = "streamer-bonuses." + code + "." + stage;
        return Math.max(0, plugin.getConfig().contains(path)
                ? plugin.getConfig().getDouble(path)
                : reward(fallbackPath));
    }
}

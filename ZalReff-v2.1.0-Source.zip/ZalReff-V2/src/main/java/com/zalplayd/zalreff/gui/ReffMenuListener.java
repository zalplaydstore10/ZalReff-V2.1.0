package com.zalplayd.zalreff.gui;

import com.zalplayd.zalreff.ZalReff;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import java.util.*;
import java.util.stream.Collectors;

public final class ReffMenuListener implements Listener {
    private final ZalReff plugin;
    private enum Page { MAIN, CODES, TOP, STREAMERS, DETAIL }
    private static final class MenuHolder implements InventoryHolder {
        final Page page; final String code;
        MenuHolder(Page page, String code) { this.page=page; this.code=code; }
        @Override public Inventory getInventory() { return null; }
    }
    public ReffMenuListener(ZalReff plugin) { this.plugin=plugin; }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private ItemStack item(String materialPath, Material fallback, String name, List<String> lore) {
        Material material = Material.matchMaterial(plugin.getConfig().getString(materialPath, fallback.name()));
        if (material == null || !material.isItem()) material=fallback;
        ItemStack stack=new ItemStack(material); ItemMeta meta=stack.getItemMeta();
        meta.setDisplayName(color(name)); meta.setLore(lore.stream().map(this::color).collect(Collectors.toList()));
        stack.setItemMeta(meta); return stack;
    }
    private Inventory create(Page page, String code, String title, int size) {
        Inventory inv=Bukkit.createInventory(new MenuHolder(page,code),size,color(title));
        Material filler=Material.matchMaterial(plugin.getConfig().getString("gui.filler-material","BLACK_STAINED_GLASS_PANE"));
        if(filler==null || !filler.isItem()) filler=Material.BLACK_STAINED_GLASS_PANE;
        ItemStack pane=item("gui.filler-material",filler," ",List.of());
        for(int i=0;i<size;i++) inv.setItem(i,pane);
        return inv;
    }
    public void open(Player p) { openMain(p); }
    public void openMain(Player p) {
        Inventory inv=create(Page.MAIN,null,"&0ZalReff &8| &bMenu Utama",27);
        inv.setItem(10,item("gui.main.codes.material",Material.NAME_TAG,"&b&lKode Referral",List.of("&7Lihat daftar kode referral","&eKlik untuk membuka")));
        inv.setItem(12,item("gui.main.top.material",Material.GOLD_INGOT,"&6&lReff Top",List.of("&7Leaderboard referral mingguan","&eKlik untuk membuka")));
        inv.setItem(14,item("gui.main.streamers.material",Material.PLAYER_HEAD,"&d&lList Streamer",List.of("&7Lihat streamer dan bonusnya","&eKlik untuk membuka")));
        inv.setItem(16,item("gui.main.info.material",Material.BOOK,"&aInformasi",List.of("&7Claim hanya sekali per pemain","&7Waktu AFK tidak dihitung","&7Valid setelah waktu aktif tercapai")));
        p.openInventory(inv);
    }
    public void openCodes(Player p) {
        Inventory inv=create(Page.CODES,null,"&0ZalReff &8| &bKode Referral",54); int slot=10;
        for(String code:plugin.data().getCodes()) { if(slot>43) break; if(slot%9==8) slot+=2; if(slot>43) break;
            String desc=plugin.getConfig().getString("referral-codes."+code+".description","Kode referral");
            inv.setItem(slot++,item("gui.codes.material",Material.NAME_TAG,"&b&l"+code,List.of("&7"+desc,"&eKlik untuk memakai kode")));
        }
        inv.setItem(49,item("gui.back.material",Material.ARROW,"&cKembali",List.of("&7Menu utama"))); p.openInventory(inv);
    }
    public void openTop(Player p) {
        Inventory inv=create(Page.TOP,null,"&0ZalReff &8| &6Reff Top",54);
        List<Map.Entry<String,Integer>> top=plugin.data().getWeeklyTop().entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey())).limit(10).toList();
        int slot=10,rank=1;
        for(var entry:top) { if(slot>43)break; if(slot%9==8)slot+=2; if(slot>43)break;
            inv.setItem(slot++,item("gui.top.material",Material.GOLD_INGOT,"&e#"+(rank++)+" &f"+entry.getKey(),List.of("&7Referral valid minggu ini","&aJumlah: &f"+entry.getValue())));
        }
        if(top.isEmpty()) inv.setItem(22,item("gui.top-empty.material",Material.BARRIER,"&cBelum ada data",List.of("&7Leaderboard masih kosong")));
        inv.setItem(49,item("gui.back.material",Material.ARROW,"&cKembali",List.of("&7Menu utama"))); p.openInventory(inv);
    }
    public void openStreamers(Player p) {
        Inventory inv=create(Page.STREAMERS,null,"&0ZalReff &8| &dList Streamer",54); int slot=10;
        for(String code:plugin.data().getCodes()) {
            String streamer=plugin.getConfig().getString("referral-codes."+code+".streamer",""); if(streamer==null || streamer.isBlank()) continue;
            if(slot>43)break; if(slot%9==8)slot+=2; if(slot>43)break;
            ItemStack head=new ItemStack(Material.PLAYER_HEAD); SkullMeta meta=(SkullMeta)head.getItemMeta(); meta.setOwningPlayer(Bukkit.getOfflinePlayer(streamer));
            meta.setDisplayName(color("&d&l"+streamer)); meta.setLore(List.of(color("&7Kode: &f"+code),color("&eKlik untuk detail"))); head.setItemMeta(meta); inv.setItem(slot++,head);
        }
        inv.setItem(49,item("gui.back.material",Material.ARROW,"&cKembali",List.of("&7Menu utama"))); p.openInventory(inv);
    }
    public void openDetail(Player p,String code) {
        String streamer=plugin.getConfig().getString("referral-codes."+code+".streamer","");
        Inventory inv=create(Page.DETAIL,code,"&0ZalReff &8| &dDetail Streamer",27);
        ItemStack head=new ItemStack(Material.PLAYER_HEAD); SkullMeta sm=(SkullMeta)head.getItemMeta(); if(streamer!=null&&!streamer.isBlank()) sm.setOwningPlayer(Bukkit.getOfflinePlayer(streamer));
        sm.setDisplayName(color("&d&l"+(streamer==null||streamer.isBlank()?"Server":streamer))); sm.setLore(List.of(color("&7Kode referral: &f"+code))); head.setItemMeta(sm); inv.setItem(11,head);
        double claim=plugin.economy().streamerReward(code,"claim","streamer-on-join"), valid=plugin.economy().streamerReward(code,"valid","streamer-on-valid");
        inv.setItem(13,item("gui.detail.claim.material",Material.EMERALD,"&aBonus Claim: &f"+claim,List.of("&7Bonus uang Vault saat kode dipakai")));
        inv.setItem(15,item("gui.detail.valid.material",Material.DIAMOND,"&bBonus Valid: &f"+valid,List.of("&7Bonus uang Vault setelah referral valid")));
        inv.setItem(22,item("gui.detail.use.material",Material.NAME_TAG,"&eGunakan Kode",List.of("&7Klik untuk claim kode &f"+code)));
        inv.setItem(26,item("gui.back.material",Material.ARROW,"&cKembali",List.of("&7Daftar streamer"))); p.openInventory(inv);
    }
    @EventHandler public void click(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p)) return;
        if(!(e.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        if(e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory()) return;
        e.setCancelled(true); ItemStack clicked=e.getCurrentItem(); if(clicked==null || !clicked.hasItemMeta())return;
        int slot=e.getRawSlot();
        switch(holder.page) {
            case MAIN -> { if(slot==10)openCodes(p); else if(slot==12)openTop(p); else if(slot==14)openStreamers(p); }
            case CODES -> { if(slot==49)openMain(p); else { String code=ChatColor.stripColor(clicked.getItemMeta().getDisplayName()); if(plugin.data().getCodes().stream().anyMatch(c->c.equalsIgnoreCase(code))) { plugin.claimReferral(p,code); p.closeInventory(); } } }
            case TOP -> { if(slot==49)openMain(p); }
            case STREAMERS -> { if(slot==49)openMain(p); else if(clicked.getItemMeta() instanceof SkullMeta sm && sm.getOwningPlayer()!=null) { String name=sm.getOwningPlayer().getName(); for(String code:plugin.data().getCodes()) if(name.equalsIgnoreCase(plugin.getConfig().getString("referral-codes."+code+".streamer",""))) { openDetail(p,code); break; } } }
            case DETAIL -> { if(slot==26)openStreamers(p); else if(slot==22 && holder.code!=null) { plugin.claimReferral(p,holder.code); p.closeInventory(); } }
        }
    }
}

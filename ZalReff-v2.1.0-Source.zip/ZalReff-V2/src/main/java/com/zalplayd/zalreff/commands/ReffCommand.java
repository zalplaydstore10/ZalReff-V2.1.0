package com.zalplayd.zalreff.commands;

import com.zalplayd.zalreff.ZalReff;
import com.zalplayd.zalreff.managers.DataManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class ReffCommand implements CommandExecutor, TabCompleter {
    private final ZalReff plugin;
    public ReffCommand(ZalReff plugin) { this.plugin=plugin; }
    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if(a.length==0 || a[0].equalsIgnoreCase("menu") || a[0].equalsIgnoreCase("list")) { if(s instanceof Player p) plugin.openMenu(p); else plugin.messages().send(s,"reff-usage"); return true; }
        if(a[0].equalsIgnoreCase("top")) { if(s instanceof Player p) plugin.openTopMenu(p); else top(s); return true; }
        
        if(a[0].equalsIgnoreCase("reload")) { if(!admin(s)) return true; plugin.reloadPlugin(); plugin.messages().send(s,"reload"); return true; }
        if(a[0].equalsIgnoreCase("cek")) { if(!admin(s)) return true; if(a.length<2) { plugin.messages().send(s,"reff-usage"); return true; } check(s,a[1]); return true; }
        if(!(s instanceof Player p)) { plugin.messages().send(s,"player-only"); return true; }
        plugin.claimReferral(p, a[0]); return true;
    }
    private boolean admin(CommandSender s) { if(s.hasPermission("zalreff.admin")) return true; plugin.messages().send(s,"no-permission"); return false; }
    private void top(CommandSender s) {
        plugin.messages().send(s,"reff-top-header"); Map<String,Integer> counts=plugin.data().getWeeklyTop();
        List<Map.Entry<String,Integer>> sorted=counts.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey())).limit(5).toList();
        if(sorted.isEmpty()) plugin.messages().send(s,"reff-top-empty"); int rank=1;
        for(var e:sorted) s.sendMessage(plugin.messages().get("reff-top-format",Map.of("rank",String.valueOf(rank++),"kode",e.getKey(),"jumlah",String.valueOf(e.getValue()))));
    }
    private void list(CommandSender s) { plugin.messages().send(s,"reff-list-header"); Collection<String> codes=plugin.data().getCodes(); if(codes.isEmpty()) plugin.messages().send(s,"reff-list-empty"); else for(String code:codes) s.sendMessage(plugin.messages().get("reff-list-format",Map.of("kode",code))); }
    private void check(CommandSender s,String name) {
        DataManager.Referral r=plugin.data().getByName(name); if(r==null) { OfflinePlayer op=Bukkit.getOfflinePlayer(name); if(!op.hasPlayedBefore()) { plugin.messages().send(s,"player-not-found",Map.of("player",name)); return; }
            plugin.messages().send(s,"cek-header",Map.of("player",name)); plugin.messages().send(s,"cek-never"); s.sendMessage(plugin.messages().get("cek-join",Map.of("joindate",date(op.getFirstPlayed())))); return; }
        OfflinePlayer op=Bukkit.getOfflinePlayer(r.uuid); plugin.messages().send(s,"cek-header",Map.of("player",r.name)); plugin.messages().send(s,"cek-code",Map.of("kode",r.code));
        plugin.messages().send(s,"cek-status",Map.of("status",plugin.messages().get(r.valid?"status-valid":"status-pending")));
        plugin.messages().send(s,"cek-playtime",Map.of("playtime",String.valueOf(r.playtimeSeconds/60),"total",String.valueOf(plugin.data().requiredSeconds()/60)));
        plugin.messages().send(s,"cek-join",Map.of("joindate",date(op.getFirstPlayed())));
    }
    private String date(long time) { return time<=0?"Unknown":new SimpleDateFormat("dd-MM-yyyy HH:mm").format(new Date(time)); }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args) {
        if(args.length==1) return Arrays.asList("top","menu","list","cek","reload").stream().filter(x->x.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if(args.length==2 && args[0].equalsIgnoreCase("cek") && s.hasPermission("zalreff.admin")) return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n->n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        return Collections.emptyList();
    }
}

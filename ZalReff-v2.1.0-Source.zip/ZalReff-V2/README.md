# ZalReff V2.1.0

Plugin referral untuk Paper dengan GUI lima halaman, validasi waktu aktif, dan reward uang melalui Vault.

## Informasi proyek

- **Nama:** ZalReff
- **Versi:** 2.1.0
- **Author:** ZALPLAYD
- **Java:** 17 / Maven
- **Target:** Paper 1.20.1–1.21.5 (uji pada versi server yang dipakai)
- **Repository:** https://github.com/zalplaydstore10/ZalReff-V2
- **YouTube:** https://youtube.com/@zalplayd?si=FmDoe2gtODHlG-i2

## Fitur

- `/reff` membuka menu utama.
- Lima GUI: menu utama, daftar kode referral, Reff Top mingguan, daftar streamer (kepala pemain), dan detail streamer.
- `/reff <kode>` untuk claim langsung; `/reff top` membuka leaderboard GUI untuk pemain.
- Satu claim per UUID pemain.
- Waktu aktif default 60 menit; aktivitas AFK tidak dihitung.
- Reward pemain dan streamer dibayar dengan Vault jika provider ekonomi tersedia.
- Bonus streamer per kode dapat diatur terpisah untuk tahap `claim` dan `valid`; jika tidak disetel, plugin memakai nominal global lama.
- Pembatasan claim berbasis permission `zalreff.blockclaim.streamer`; rank lain tidak diblokir kecuali diberi permission tersebut.

## Konfigurasi bonus streamer

Contoh di `config.yml`:

```yaml
streamer-bonuses:
  MEKK:
    claim: 250.0
    valid: 500.0
  BUDI12:
    claim: 300.0
    valid: 700.0
```

`claim` dibayarkan ke akun streamer saat kode digunakan. `valid` dibayarkan saat referral mencapai waktu aktif yang disyaratkan. Keduanya merupakan uang Vault.

## Ikon GUI

Material di bagian `gui:` dapat diganti dengan nama material Minecraft seperti `DIAMOND_SWORD`, `EMERALD`, `BOOK`, atau `PLAYER_HEAD`. Ikon hanya dekorasi GUI, bukan hadiah item.

## Permission Streamer (LuckPerms)

```text
/lp group streamer permission set zalreff.blockclaim.streamer true
```

Jangan berikan permission ini kepada grup lain jika hanya Streamer yang harus diblokir. Permission admin `zalreff.admin` default OP.

## Dependensi dan build

- Paper + Java 17
- Vault dan plugin ekonomi yang menyediakan Vault Economy (misalnya EssentialsX Economy)

Jalankan `mvn --batch-mode clean package` dari folder `ZalReff-V2`. Hasil JAR: `target/ZalReff-V2.jar`. GitHub Actions workflow tersedia di `.github/workflows/build.yml`; workflow dapat mengekstrak satu ZIP source di root repository sebelum menjalankan Maven.

## Instalasi

1. Build source menjadi JAR.
2. Pasang Vault dan plugin ekonomi.
3. Letakkan `ZalReff-V2.jar` di folder `plugins`.
4. Restart server dan edit `plugins/ZalReff/config.yml`.
5. Uji claim, bonus, GUI, dan permission pada server percobaan.

## Catatan verifikasi

Source diperbarui dari V2.0.0. Build Maven belum dapat dijalankan pada lingkungan penyusunan arsip ini; pastikan GitHub Actions atau Maven lokal berhasil sebelum memasang ke server utama.
